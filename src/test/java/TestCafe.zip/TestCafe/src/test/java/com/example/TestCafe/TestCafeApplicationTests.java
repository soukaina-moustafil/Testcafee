package com.example.TestCafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
